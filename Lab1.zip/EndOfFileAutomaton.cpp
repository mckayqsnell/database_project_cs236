#include "EndOfFileAutomaton.h"

void EndOfFileAutomaton::S0(const std::string& input){}